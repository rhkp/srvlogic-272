SET SEARCH_PATH="data-index-service";
CREATE TABLE DIMyTable2 (
    MyColumn VARCHAR(100) NOT NULL
);