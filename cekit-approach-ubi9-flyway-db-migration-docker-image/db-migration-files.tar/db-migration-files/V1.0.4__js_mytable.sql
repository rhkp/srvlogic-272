SET SEARCH_PATH="jobs-service";
CREATE TABLE JSMyTable (
    MyColumn VARCHAR(100) NOT NULL
);
